/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package cinefat.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CinefatController implements Initializable {

    @FXML
    private TextField txtNumero_1;
    @FXML
    private TextField txtNumero_2;
    @FXML
    private TextField txtResultado;
    @FXML
    private Button btnSomar;
    @FXML
    private Button btnSubtrair;
    @FXML
    private Button btnFechar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnSomar_Click(ActionEvent event) {
        int n1, n2, resultado;
        
        try
        {
            //busca o conteudo do jtextfield
            //converte de String para numero
            n1 = Integer.parseInt(txtNumero_1.getText());
            n2 = Integer.parseInt(txtNumero_2.getText());
        }
        //captura erro de formato de numero
        catch (NumberFormatException erro) {
            //gerar um aviso
            mensagem("Um dos números está inválido!!!");
            
            //cai fora
            return;
        }
        
        //calcula
        resultado = n1 + n2;
        
        //exibe na tela
        //converte de numero para String
        txtResultado.setText(String.valueOf(resultado));
    }

    @FXML
    private void btnSubtrair_Click(ActionEvent event) {
        int n1, n2, resultado;
        
        try
        {
            //busca o conteudo do jtextfield
            //converte de String para numero
            n1 = Integer.parseInt(txtNumero_1.getText());
            n2 = Integer.parseInt(txtNumero_2.getText());
        }
        //captura erro de formato de numero
        catch (NumberFormatException erro) {
            //gerar um aviso
            mensagem("Um dos números está inválido!!!");
            
            //cai fora
            return;
        }
        
        //calcula
        resultado = n1 - n2;
        
        //exibe na tela
        //converte de numero para String
        txtResultado.setText(String.valueOf(resultado));
    }

    @FXML
    private void btnFechar_Click(ActionEvent event) {
        //fechar a janela
        ((Stage)btnFechar.getScene().getWindow()).close();
    }
    
    private void mensagem(String msg) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("Mensagem");
        alerta.setHeaderText(msg);
        alerta.setContentText("");

        alerta.showAndWait(); //exibe a mensage
    }
}
