module com.mycompany.borala {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.borala to javafx.fxml;
    exports com.mycompany.borala;
}
